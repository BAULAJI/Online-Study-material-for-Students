<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notesworm NEET</title>
    <style>
        span{
            background-color:blue;
            color: white;
            padding: 16px;
            border-radius: 16px;
           font-weight: bolder;
           font-size:x-large;
        }
        span :hover{
            padding: 5px;
            transition: 0.6s;
            color:black;
        }
        a{
            color: white;
        }
       #about{
        background-color: black;
       }
       #about a{
        text-decoration: none;
       }
        
       .c2 a{
         color: black;
       }
       summary{
        font-size:x-large;
       }
       header{
            background-color: rgba(146, 75, 111, 0.274);
        }
        body{
            background-color:blanchedalmond;
            margin: 0;
            scroll-behavior: smooth;
        }
        fieldset{
            border-color:crimson;
            border-width: 10px;
            background-image: url(https://w0.peakpx.com/wallpaper/972/48/HD-wallpaper-stack-of-books-blue-background-education-concepts-books-library-school-learning-concepts.jpg );
            background-repeat: no-repeat;
            background-size: cover;
            margin: 0;
        }
        header{
            background-image: url(https://images.unsplash.com/photo-1472289065668-ce650ac443d2?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGVhZGVyfGVufDB8fDB8fHww);
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>
<body>
   <center> <header>
        <img src="https://media1.giphy.com/media/IhIDRwEVka6plLPC9z/giphy.gif" width="150" height="150" style="">
        <h1>NOTESWORM</h1>
        <br>
        <span><a href="homef.php" style="text-decoration: none;">Home</a></span>
        <span><a href="tenf.php" style="text-decoration: none;"target="blank" >10th</a></span>
        <span><a href="elevenf.php" style="text-decoration: none;"target="blank">11th</a></span>
        <span><a href="twelevef.php" style="text-decoration: none;"target="blank">12th</a></span>
        <span><a href="neetf.php" style="text-decoration: none;"target="blank">NEET</a></span>
        <span><a href="jeef.php" style="text-decoration: none;"target="blank">JEE</a></span>
        <span><a href="login1oslt.php" style="text-decoration: none;"target="blank">Login</a></span>
        <span><a href="regff.php" style="text-decoration: none;"target="blank">Register</a></span>
        <span><a href="#about" style="text-decoration: none;" >About Us</a></span><br><br> 
    </header> </center>
    <br>
    <center><img src="https://play-lh.googleusercontent.com/HS-SAMsnnhnH20lPF9E2cWRBJv9IdlMxWxWf1ONzHD6TZNZqAe_N05cSMnWaej2HZA" width="400" height="400"></center>
   <fieldset> <div class="c2">
    <details>
        <summary>Botany</summary>
        <br><ul>
            <li>
        <a href="https://www.selfstudys.com/advance-pdf-viewer/neet-biology/english/notes/4-plant-physlology/4-1-transport-in-plant/185067" target="blank"  style="text-decoration: none;">Notes</a><br><br></li>
        <li>
        <a href="https://youtube.com/playlist?list=PLrl4F_rRUyHu7FeZRymwVW5CqvqM1Kn_r&si=wI2UURM_zJhbV8Nd" target="blank"  style="text-decoration: none;">Youtube link</a><br><br></li></ul>
       
    </details>
    <details>
        <summary>Zoology</summary>
        <br><ul>
            <li>
        <a href="https://translate.google.com/website?sl=en&tl=ta&hl=ta&client=srp&u=https://padasalai.info/wp-content/uploads/2023/04/NEET-Exam-TM-Zoology-Study-Materials-Tamil-Medium-PDF-Download.pdf" target="blank"  style="text-decoration: none;">Notes</a><br><br></li>
        <li>
        <a href="https://youtu.be/odz4MtDT0D8?si=V73m72xRTz8v-_c2" target="blank"  style="text-decoration: none;">Youtube link</a><br><br></li></ul>

    </details>
    <details>
        <summary>Chemistry</summary>
        <br><ul>
            <li>
        <a href="https://translate.google.com/website?sl=en&tl=ta&hl=ta&client=srp&u=https://padasalai.info/wp-content/uploads/2022/11/Neet-Chemistry-2018-Answer-Keys-2022-2023-Tamil-Medium-PDF-Download.pdf" target="blank"  style="text-decoration: none;">Notes</a><br><br></li>
        <li>
        <a href="https://youtube.com/playlist?list=PLg99mcrxFRz9L2Ihdxdheub-bUSKlpB-K&si=7D3cQvCiM6Qj8VjK" target="blank"  style="text-decoration: none;">Youtube link</a><br><br></li></ul>
       
    </details>
    <details>
        <summary>Physics</summary>
        <br><ul>
            <li>
        <a href="https://translate.google.com/website?sl=en&tl=ta&hl=ta&client=srp&u=https://padasalai.info/wp-content/uploads/2022/11/Physics-Neet-Amma-Study-Material-2022-2023-Tamil-Medium-PDF-Download-1.pdf" target="blank"  style="text-decoration: none;">Notes</a><br><br></li>
        <li>
        <a href="https://youtube.com/playlist?list=PL88pFyKkusEEJKSshjtPEO-J0GnjRoaQE&si=75aiyn2c68pcvrop" target="blank"  style="text-decoration: none;">Youtube link</a><br><br></li></ul>
       
    </details>
    <details>
        <summary>Practice Questions</summary>
        
        <br><ul><li><a href="https://translate.google.com/website?sl=en&tl=ta&hl=ta&client=srp&u=https://padasalai.info/wp-content/uploads/2022/11/Neet-2016-Physics-Chemistry-and-Biology-Answer-Keys-and-Solutions-2022-2023-English-Medium-PDF-Download-1.pdf" target="blank"  style="text-decoration: none;">Notes</a><br><br></li></ul>
       
    </details>
   
</div></fieldset>
<footer>
    <center><div id="about">
        <a href="https://instagram.com/butter_bala?utm_source=qr&igshid=OGIxMTE0OTdkZA==" target="blank"><img src="https://wallpapers.com/images/hd/instagram-black-background-1024-x-1024-llskolakbt9ceeb8.jpg" width="100" height="100" style="padding:25px"></a>
        <a href="https://www.linkedin.com/in/balaji-r-987333231?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"><img src="https://s.widget-club.com/samples/SkKKnH4BdhhNhbwYwAUv8OzzsT23/BcU6njZe1Pz4Gnid8Idv/7EB8B1F4-FCC2-4700-8B97-4CE81F8B0E74.jpg?q=70" width="100" height="100" target="blank" style="padding:25px"></a>
        <a href="https://github.com/BAULAJI"><img src="https://i.pinimg.com/736x/b5/1b/78/b51b78ecc9e5711274931774e433b5e6.jpg" width="80" height="80" target="blank" style="padding:25px"></a>
    </div></center>
</footer>
</body>
</html>