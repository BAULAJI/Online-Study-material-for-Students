<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notesworm 11th</title>
    <style>
        span{
            background-color:blue;
            color: white;
            padding: 16px;
            border-radius: 16px;
           font-weight: bolder;
           font-size:x-large;
        }
         span :hover{
            padding: 5px;
            transition: 0.6s;
            color:black;
        }
        a{
            color: white;
        }
       #about{
        background-color: black;
       }
       #about a{
        text-decoration: none;
       }
        
       .c2 a{
         color: black;
       }
       summary{
        font-size:x-large;
       }
       header{
            background-color: rgba(146, 75, 111, 0.274);
        }
        body{
            background-color:blanchedalmond;
            margin: 0;
            scroll-behavior: smooth;
        }
        fieldset{
            border-color:crimson;
            border-width: 10px; background-image: url(https://w0.peakpx.com/wallpaper/972/48/HD-wallpaper-stack-of-books-blue-background-education-concepts-books-library-school-learning-concepts.jpg );
            background-repeat: no-repeat;
            background-size: cover;
            margin: 0;
        }
        header{
            background-image: url(https://images.unsplash.com/photo-1472289065668-ce650ac443d2?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGVhZGVyfGVufDB8fDB8fHww);
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>
<body>
   <center> <header>
        <img src="https://media1.giphy.com/media/IhIDRwEVka6plLPC9z/giphy.gif" width="150" height="150" >
        <h1>NOTESWORM</h1>
        <br>
        <span><a href="homef.php" style="text-decoration: none;">Home</a></span>
        <span><a href="tenf.php" style="text-decoration: none;"target="blank" >10th</a></span>
        <span><a href="elevenf.php" style="text-decoration: none;"target="blank">11th</a></span>
        <span><a href="twelevef.php" style="text-decoration: none;"target="blank">12th</a></span>
        <span><a href="neetf.php" style="text-decoration: none;"target="blank">NEET</a></span>
        <span><a href="jeef.php" style="text-decoration: none;"target="blank">JEE</a></span>
        <span><a href="login1oslt.php" style="text-decoration: none;"target="blank">Login</a></span>
        <span><a href="regff.php" style="text-decoration: none;"target="blank">Register</a></span>
        <span><a href="#about" style="text-decoration: none;" >About Us</a></span><br><br> 
    </header> </center>
    <center><img src="https://hybriques.com/wp-content/uploads/2022/09/class11.png" width="400" height="400"></center>
    <fieldset><div class="c2">
    <details>
        <summary>Tamil</summary>
        <br><ul>
            <li>
        <a href="https://padasalai.info/wp-content/uploads/2023/08/11th-Tamil-Full-Study-Materials-PDF-Download.pdf" target="blank" style="text-decoration: none;">Notes</a><br><br></li>
        <li><a href="https://youtu.be/vZtVh7c6zco?si=VB2sN77KMDCSdjSI"target="blank" style="text-decoration: none;">Youtube Link</a><br><br></li></ul>
    </details>
    <details>
        <summary>English</summary>
        <br><ul>
            <li>
        <a href="https://padasalai.info/wp-content/uploads/2023/07/11th-English-Full-Study-Material-PDF-Download.pdf" target="blank" style="text-decoration: none;">Notes</a><br><br></li>
       <li> <a href="https://youtu.be/lunvl0GKOnA?si=WtE3NkN4jWp3GkhW" target="blank" style="text-decoration: none;">Youtube link</a><br><br></li></ul>
    </details>
    <details>
        <summary>Maths</summary>
        <br><ul>
            <li>
        <a href="https://drive.google.com/file/d/1gqhGn3g6eU1W47vOVZDEpom2yn6FUCX3/view?usp=sharing" target="blank" style="text-decoration: none;">Notes</a><br><br></li>
       <li> <a href="https://youtube.com/playlist?list=PL2qtWkm0Z4ccmrxoNjy2bgOWW8Jddu_0k&si=UfFGvoqSj128_wvp" target="blank" style="text-decoration: none;">Youtube link</a><br><br></li></ul>
       
    </details>
    <details>
        <summary>Biology</summary>
        <br><ul>
            <li>
        <a href="https://drive.google.com/file/d/1nV7lROAzS43gBYqluWyPDZ29bSmXVPEm/view?usp=sharing" target="blank" style="text-decoration: none;">Notes</a><br><br></li>
        <li><a href="https://youtube.com/playlist?list=PLjFLphY_mFmsxh8MLfduFzJsImEHk7u9D&si=jV4BFjlxED7p3b-l" target="blank" style="text-decoration: none;">Youtube link</a><br><br></li></ul>

    </details>
    <details>
        <summary>Chemistry</summary>
        <br><ul>
            <li>
        <a href="https://padasalai.info/wp-content/uploads/2023/07/11th-Chemistry-EM-Minimum-Study-Material-English-Medium-PDF-Download.pdf" target="blank" style="text-decoration: none;">Notes</a><br><br></li>
       <li> <a href="https://youtube.com/playlist?list=PLg99mcrxFRz9S9Ot-YSSvlcTiu4hi9sYJ&si=r3CTtotHoWbhazm6" target="blank" style="text-decoration: none;">Youtube link</a><br><br></li></ul>
       
    </details>
    <details>
        <summary>Physics</summary>
        <br><ul>
            <li>
        <a href="https://drive.google.com/file/d/1Nm0WDUSZGEFyqbxeD5ia3R1CN3JlIYkZ/view?usp=sharing" target="blank" style="text-decoration: none;">Notes</a><br><br></li>
        <li><a href="https://youtube.com/playlist?list=PL2qtWkm0Z4cdMyuYF9rUEMJQzajuV7doX&si=PpRvy84q47gTdFm_" target="blank" style="text-decoration: none;">Youtube link</a><br><br></li></ul>
       
    </details>
    <details>
        <summary>Computer Science</summary>
        <br><ul>
            <li>
        <a href="https://padasalai.info/wp-content/uploads/2022/09/11th-Computer-Science-EM-Full-Study-Material-English-Medium-PDF-Download.pdf" target="blank" style="text-decoration: none;">Notes</a><br><br>
        <a href="https://youtu.be/c62E7Ny-oww?si=5hjswoIRXyTNJw1h" target="blank" style="text-decoration: none;">Youtube link</a><br><br>
    </li></ul>
    </details>
    <details>
        <summary>Commerce</summary>
        <br><ul>
            <li>
        <a href="https://padasalai.info/wp-content/uploads/2023/08/11th-Commerce-EM-Full-Guide-English-Medium-PDF-Download.pdf" target="blank" style="text-decoration: none;">Notes</a><br><br></li>
        <li>
        <a href="https://youtube.com/playlist?list=PLpc0Iv2hS3m-CtQAA4kNhmYL7_R7-LeCO&si=EvLakZkSJleklAcW" target="blank" style="text-decoration: none;">Youtube link</a><br><br></li></ul>
       
    </details>
    <details>
        <summary>Accountancy</summary>
        <br><ul>
            <li>
        <a href="https://drive.google.com/file/d/16O-x-tRh-dmYsrVOUQIyzNVMJgRjuQSH/view?usp=sharing" target="blank" style="text-decoration: none;">Notes</a><br><br></li>
        <li>
        <a href="https://youtube.com/playlist?list=PLICT6wocaAmTaiA0_mRPLOdb022BD14a-&si=xnrFQ7X97Tnty9m4" target="blank" style="text-decoration: none;">Youtube link</a><br><br></li></ul>
    </details>
    <details>
        <summary>Business Maths</summary>
        <br><ul>
            <li>
        <a href="https://drive.google.com/file/d/1RcWQAT2DI2zsMz1SfXmHajY5E3fTv4XQ/view?usp=sharing" target="blank" style="text-decoration: none;">Notes</a><br><br></li>
        <li><a href="https://youtube.com/playlist?list=PL2qtWkm0Z4cd_mS29yRnivMWVrpyVWw8E&si=FZHm82kE6T-x9LBp
        " target="blank" style="text-decoration: none;">Youtube link</a><br><br></li></ul>
       
    </details>
</div></fieldset>
<footer>
    <center><div id="about">
        <a href="https://instagram.com/butter_bala?utm_source=qr&igshid=OGIxMTE0OTdkZA==" target="blank"><img src="https://wallpapers.com/images/hd/instagram-black-background-1024-x-1024-llskolakbt9ceeb8.jpg" width="100" height="100" style="padding:25px"></a>
        <a href="https://www.linkedin.com/in/balaji-r-987333231?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"><img src="https://s.widget-club.com/samples/SkKKnH4BdhhNhbwYwAUv8OzzsT23/BcU6njZe1Pz4Gnid8Idv/7EB8B1F4-FCC2-4700-8B97-4CE81F8B0E74.jpg?q=70" width="100" height="100" target="blank" style="padding:25px"></a>
        <a href="https://github.com/BAULAJI"><img src="https://i.pinimg.com/736x/b5/1b/78/b51b78ecc9e5711274931774e433b5e6.jpg" width="80" height="80" target="blank" style="padding:25px"></a>
    </div></center>
</footer>
</body>
</html>