<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NotesWorm</title>
    <style>
        span{
            background-color:blue;
            color: white;
            padding: 16px;
            border-radius: 16px;
           font-weight: bolder;
           font-size:x-large;
        }
        span :hover{
            padding: 5px;
            transition: 0.6s;
            color:black;
        }
        a{
            color: white;
        }
       #about{
        background-color: black;
       }
       #about a{
        text-decoration: none;
       }
       header{
            background-color: rgba(146, 75, 111, 0.274);
        }
        body{
            background-color:blanchedalmond;
            margin: 0;
            scroll-behavior: smooth;
        }
        fieldset{
            border-color:crimson;
            border-width: 10px;
            margin: 0;
        }
        header{
            background-image: url(https://images.unsplash.com/photo-1472289065668-ce650ac443d2?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGVhZGVyfGVufDB8fDB8fHww);
            background-repeat: no-repeat;
            background-size: cover;
        }
        .ho{
            font-size: large;
        }
    </style>
</head>
<body>
    <!-- <nav>
        <svg width="400" height="70">
           <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" style="stop-color:rgb(255,255,0);stop-opacity:1"/>
                <stop offset="100%" style="stop-color:rgb(255,0,0);stop-opacity:1"/>
            </linearGradient>
           </defs>
           <ellipse cx="100" cy="70" rx="85" ry="55" fill="url(#grad1)"/>
           <text fill="#ffffff" font-size="45" font-family="Vedana" x="50" y="86">NW</text>
           Sorry,Your Browser does not Support to inline SVG.
        </svg>
    </nav> -->
   

    <div class="d1">
        
    <center> 
        
      
    <header>
        <img src="https://media1.giphy.com/media/IhIDRwEVka6plLPC9z/giphy.gif" width="150" height="150">
        <h1>NOTESWORM</h1>
        <br>
        <span >Home</span>
        <span><a href="tenf.php" style="text-decoration: none;"target="blank" >10th</a></span>
        <span><a href="elevenf.php" style="text-decoration: none;"target="blank">11th</a></span>
        <span><a href="twelevef.php" style="text-decoration: none;"target="blank">12th</a></span>
        <span><a href="neetf.php" style="text-decoration: none;"target="blank">NEET</a></span>
        <span><a href="jeef.php" style="text-decoration: none;"target="blank">JEE</a></span>
        <span><a href="login1oslt.php" style="text-decoration: none;"target="blank">Login</a></span>
        <span><a href="regff.php" style="text-decoration: none;"target="blank">Register</a></span>
        <span><a href="#about" style="text-decoration: none;" >About Us</a></span><br><br> 
    </header> </center>  </div>

    <fieldset><id class="ho">
        <h3>Courses available</h3>
        <P>This websites consist of 10th,11th and 12th Syllabus,Guide,Youtube videos,and many more..It is also contains the NEET and JEE materials for preparing the exams. The website can be used to upload educational materials such as lecture notes, presentations, and other resources that can help students in their studies</P>
        <ul>
          <li>10th class</li>
          <li>11th class</li>
          <li>12th class</li>
          <li>NEET class</li>
          <li>JEE class</li>
        </ul>
        <br><br>
        <center><iframe width="1000" height="608" src="https://www.youtube.com/embed/ltau6Q4wOvo" title="TN Samacheer 10th std  Maths New Syllabus Chapter 3 Algebra Exercise 3.2 q.no.1 Alexmaths" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        <iframe width="1000" height="608" src="https://www.youtube.com/embed/5m4fRQ7DxAE" title="Relationship between Enthalpy(H) and Internal energy(U)/Thermodynamics/11th chemistry/vol 1/in tamil" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        <iframe width="1000" height="608" src="https://www.youtube.com/embed/_zEGRfarJVY" title="12 COMMERCE CHAPTER -1 principles of management PART. 1  in tamil" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></center></fieldset>
        <center><div id="about">
            <a href="https://instagram.com/butter_bala?utm_source=qr&igshid=OGIxMTE0OTdkZA==" target="blank"><img src="https://wallpapers.com/images/hd/instagram-black-background-1024-x-1024-llskolakbt9ceeb8.jpg" width="100" height="100" style="padding:25px"></a>
            <a href="https://www.linkedin.com/in/balaji-r-987333231?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"><img src="https://s.widget-club.com/samples/SkKKnH4BdhhNhbwYwAUv8OzzsT23/BcU6njZe1Pz4Gnid8Idv/7EB8B1F4-FCC2-4700-8B97-4CE81F8B0E74.jpg?q=70" width="100" height="100" target="blank" style="padding:25px"></a>
            <a href="https://github.com/BAULAJI"><img src="https://i.pinimg.com/736x/b5/1b/78/b51b78ecc9e5711274931774e433b5e6.jpg" width="80" height="80" target="blank" style="padding:25px"></a>
        </div></center>
    </id>
</body>
</html>