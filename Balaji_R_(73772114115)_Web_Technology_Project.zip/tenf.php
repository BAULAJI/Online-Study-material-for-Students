<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notesworm 10th</title>
    <style>
        span{
            background-color:blue;
            color: white;
            padding: 16px;
            border-radius: 16px;
           font-weight: bolder;
           font-size:x-large;
        }
        span :hover{
            padding: 5px;
            transition: 0.6s;
            color:black;
        }
        a{
            color: white;
        }
       #about{
        background-color: black;
       }
       #about a{
        text-decoration: none;
       }
    
        
       .c2 a{
         color: black;
       }
       summary{
        font-size:x-large;
       }
       header{
            background-color: rgba(146, 75, 111, 0.274);
        }
        body{
            background-color:blanchedalmond;
            margin: 0;
            scroll-behavior: smooth;
        }
        fieldset{
            border-color:crimson;
            border-width: 10px;
            background-image: url(https://w0.peakpx.com/wallpaper/972/48/HD-wallpaper-stack-of-books-blue-background-education-concepts-books-library-school-learning-concepts.jpg );
            background-repeat: no-repeat;
            background-size: cover;
            margin: 0;
        }
        header{
            background-image: url(https://images.unsplash.com/photo-1472289065668-ce650ac443d2?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGVhZGVyfGVufDB8fDB8fHww);
            background-repeat: no-repeat;
            background-size: cover;
        }
       
    </style>
</head>
<body>
   <center> <header>
        <img src="https://media1.giphy.com/media/IhIDRwEVka6plLPC9z/giphy.gif" width="150" height="150" style="">
        <h1>NOTESWORM</h1>
        <br>
        <span><a href="homef.php" style="text-decoration: none;">Home</a></span>
        <span><a href="tenf.php" style="text-decoration: none;"target="blank" >10th</a></span>
        <span><a href="elevenf.php" style="text-decoration: none;"target="blank">11th</a></span>
        <span><a href="twelevef.php" style="text-decoration: none;"target="blank">12th</a></span>
        <span><a href="neetf.php" style="text-decoration: none;"target="blank">NEET</a></span>
        <span><a href="jeef.php" style="text-decoration: none;"target="blank">JEE</a></span>
        <span><a href="login1oslt.php" style="text-decoration: none;"target="blank">Login</a></span>
        <span><a href="regff.php" style="text-decoration: none;"target="blank">Register</a></span>
        <span><a href="#about" style="text-decoration: none;" >About Us</a></span><br><br> 
    </header> </center>
    <center><img src="https://qph.cf2.quoracdn.net/main-qimg-a5b3f2661f99560bb0d217de860f79e0" width="400" height="400" ></center>
    <fieldset><div class="c2">
    <details>
        <summary>Tamil</summary>
        <br><ul>
        <li><a href="C:\Users\ELCOT\Downloads\10th-Tamil-Slow-Learners-Study-Materials-Tamil-Medium-PDF-Download.pdf" target="blank" style="text-decoration: none;"target="blank">Notes</a><br><br></li>
        <li><a href="https://www.youtube.com/watch?v=h_0VjZ_IJRM"target="blank" style="text-decoration: none;"target="blank">Youtube Link</a><br><br></li></ul>
    </details>
    <details>
        <summary>English</summary>
        <br><ul>
            <li>
        <a href="https://drive.google.com/uc?export=download&id=1zaSfFjDDxLCGJhaJM2FVPCSiu9wgwQZd" target="blank" style="text-decoration: none;"target="blank">Notes</a><br><br></li>
        <li><a href="https://youtu.be/nEEhMQOKW2I" target="blank" style="text-decoration: none;"target="blank">Youtube link</a><br><br></li></ul>
    </details>
    <details>

        <summary>Maths</summary>
        <br><ul>
            <li>
        <a href="https://drive.google.com/uc?export=download&id=1ihmTxQ8c5znHKkIQYMSbR3-4S9mbv_4Y" target="blank" style="text-decoration: none;"target="blank">Notes</a><br><br></li>
        <li><a href="https://youtu.be/2fmcHDQSYRo" target="blank" style="text-decoration: none;"target="blank">Youtube link</a><br><br></li></ul>
       
    </details>
    <details>
        <summary>Science</summary>
        <br><ul>
            <li>
        <a href="https://drive.google.com/uc?export=download&id=11wEM8smY-KqEyA3qaU2TdOLGyC5B4B2_" target="blank" style="text-decoration: none;"target="blank">Notes</a><br><br></li>
        <li><a href="https://youtu.be/LsUTvBm1xZo" target="blank" style="text-decoration: none;"target="blank">Youtube link</a><br><br></li></ul>

    </details>
    <details>
        <summary>Social</summary>
        <br><ul>
            <li>
        <a href="https://drive.google.com/uc?export=download&id=1duHL1rMiGiw0fE4Ixh-EzyVCrzVhv9ct" target="blank" style="text-decoration: none;"target="blank">Notes</a><br><br></li>
        <li><a href="https://youtu.be/8ancLdWy__g" target="blank" style="text-decoration: none;"target="blank">Youtube link</a><br><br></li></ul>
       
    </details>
</div></fieldset>
<footer>
    <center><div id="about">
        <a href="https://instagram.com/butter_bala?utm_source=qr&igshid=OGIxMTE0OTdkZA==" target="blank"><img src="https://wallpapers.com/images/hd/instagram-black-background-1024-x-1024-llskolakbt9ceeb8.jpg" width="100" height="100" style="padding:25px"></a>
        <a href="https://www.linkedin.com/in/balaji-r-987333231?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"><img src="https://s.widget-club.com/samples/SkKKnH4BdhhNhbwYwAUv8OzzsT23/BcU6njZe1Pz4Gnid8Idv/7EB8B1F4-FCC2-4700-8B97-4CE81F8B0E74.jpg?q=70" width="100" height="100" target="blank" style="padding:25px"></a>
        <a href="https://github.com/BAULAJI"><img src="https://i.pinimg.com/736x/b5/1b/78/b51b78ecc9e5711274931774e433b5e6.jpg" width="80" height="80" target="blank" style="padding:25px"></a>
    </div></center>
</footer>
</body>
</html>